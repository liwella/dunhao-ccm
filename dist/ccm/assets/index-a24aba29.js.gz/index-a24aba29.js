var Ee=(e,r,t)=>new Promise((o,a)=>{var d=s=>{try{u(t.next(s))}catch(i){a(i)}},c=s=>{try{u(t.throw(s))}catch(i){a(i)}},u=s=>s.done?o(s.value):Promise.resolve(s.value).then(d,c);u((t=t.apply(e,r)).next())});import{_ as mt}from"./CommonPage-06556ed1.js";import{_ as vt}from"./TheIcon-e8a5b0d0.js";import{ao as oe,h as n,d as te,T as Ke,b as se,M as ze,ap as wt,aq as bt,ar as Ct,Z as U,c as w,as as He,at as xt,a1 as yt,a6 as $,q as V,a7 as Je,au as _e,av as me,aw as Qe,O as re,e as E,u as ge,g as De,ax as Rt,ay as _t,K as Ae,az as Tt,aA as Te,aB as fe,N,af as kt,x as Lt,aC as Ot,aD as Be,aa as Me,aE as Pt,C as Ne,a5 as Ie,$ as j,aF as St,f as Bt,aG as Ce,ad as It,Y as et,U as zt,_ as ue,P as Dt,aH as Mt,a0 as Ve,a as Q,a2 as $t,aI as jt,aJ as Ft,aK as Ut,a8 as Et,a9 as Xe,aL as Ht,aM as At,o as ce,j as ke,w as K,k as ee,n as Le,m as ve,l as le,ae as We,aN as Ze,F as Nt,L as Vt}from"./index-fcd7eebc.js";import{u as Xt}from"./use-compitable-3d6c947e.js";import{A as Wt}from"./Add-4d77b51b.js";import{N as Zt}from"./Progress-31e44720.js";import{u as qt}from"./use-locale-ea43045e.js";import{N as Yt}from"./Tooltip-1bd68290.js";import{b as Gt}from"./get-eaa4dfe4.js";import{E as Kt}from"./Eye-1bd242ac.js";import{u as Jt}from"./use-merged-state-3264fb8d.js";import{_ as Qt}from"./Space-7ee4e193.js";import"./AppPage-7316f500.js";import"./_plugin-vue_export-helper-c27b6911.js";import"./icon-7bfbf4ba.js";import"./Popover-f5e6c032.js";const eo=oe("attach",n("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},n("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},n("g",{fill:"currentColor","fill-rule":"nonzero"},n("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),to=oe("trash",n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},n("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),n("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),n("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),n("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),oo=oe("download",n("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},n("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},n("g",{fill:"currentColor","fill-rule":"nonzero"},n("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),no=oe("cancel",n("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},n("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},n("g",{fill:"currentColor","fill-rule":"nonzero"},n("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),ro=oe("retry",n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},n("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),n("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),io=oe("rotateClockwise",n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10C17 12.7916 15.3658 15.2026 13 16.3265V14.5C13 14.2239 12.7761 14 12.5 14C12.2239 14 12 14.2239 12 14.5V17.5C12 17.7761 12.2239 18 12.5 18H15.5C15.7761 18 16 17.7761 16 17.5C16 17.2239 15.7761 17 15.5 17H13.8758C16.3346 15.6357 18 13.0128 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 10.2761 2.22386 10.5 2.5 10.5C2.77614 10.5 3 10.2761 3 10Z",fill:"currentColor"}),n("path",{d:"M10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12ZM10 11C9.44772 11 9 10.5523 9 10C9 9.44772 9.44772 9 10 9C10.5523 9 11 9.44772 11 10C11 10.5523 10.5523 11 10 11Z",fill:"currentColor"}))),ao=oe("rotateClockwise",n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M17 10C17 6.13401 13.866 3 10 3C6.13401 3 3 6.13401 3 10C3 12.7916 4.63419 15.2026 7 16.3265V14.5C7 14.2239 7.22386 14 7.5 14C7.77614 14 8 14.2239 8 14.5V17.5C8 17.7761 7.77614 18 7.5 18H4.5C4.22386 18 4 17.7761 4 17.5C4 17.2239 4.22386 17 4.5 17H6.12422C3.66539 15.6357 2 13.0128 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 10.2761 17.7761 10.5 17.5 10.5C17.2239 10.5 17 10.2761 17 10Z",fill:"currentColor"}),n("path",{d:"M10 12C8.89543 12 8 11.1046 8 10C8 8.89543 8.89543 8 10 8C11.1046 8 12 8.89543 12 10C12 11.1046 11.1046 12 10 12ZM10 11C10.5523 11 11 10.5523 11 10C11 9.44772 10.5523 9 10 9C9.44772 9 9 9.44772 9 10C9 10.5523 9.44772 11 10 11Z",fill:"currentColor"}))),lo=oe("zoomIn",n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M11.5 8.5C11.5 8.22386 11.2761 8 11 8H9V6C9 5.72386 8.77614 5.5 8.5 5.5C8.22386 5.5 8 5.72386 8 6V8H6C5.72386 8 5.5 8.22386 5.5 8.5C5.5 8.77614 5.72386 9 6 9H8V11C8 11.2761 8.22386 11.5 8.5 11.5C8.77614 11.5 9 11.2761 9 11V9H11C11.2761 9 11.5 8.77614 11.5 8.5Z",fill:"currentColor"}),n("path",{d:"M8.5 3C11.5376 3 14 5.46243 14 8.5C14 9.83879 13.5217 11.0659 12.7266 12.0196L16.8536 16.1464C17.0488 16.3417 17.0488 16.6583 16.8536 16.8536C16.68 17.0271 16.4106 17.0464 16.2157 16.9114L16.1464 16.8536L12.0196 12.7266C11.0659 13.5217 9.83879 14 8.5 14C5.46243 14 3 11.5376 3 8.5C3 5.46243 5.46243 3 8.5 3ZM8.5 4C6.01472 4 4 6.01472 4 8.5C4 10.9853 6.01472 13 8.5 13C10.9853 13 13 10.9853 13 8.5C13 6.01472 10.9853 4 8.5 4Z",fill:"currentColor"}))),so=oe("zoomOut",n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M11 8C11.2761 8 11.5 8.22386 11.5 8.5C11.5 8.77614 11.2761 9 11 9H6C5.72386 9 5.5 8.77614 5.5 8.5C5.5 8.22386 5.72386 8 6 8H11Z",fill:"currentColor"}),n("path",{d:"M14 8.5C14 5.46243 11.5376 3 8.5 3C5.46243 3 3 5.46243 3 8.5C3 11.5376 5.46243 14 8.5 14C9.83879 14 11.0659 13.5217 12.0196 12.7266L16.1464 16.8536L16.2157 16.9114C16.4106 17.0464 16.68 17.0271 16.8536 16.8536C17.0488 16.6583 17.0488 16.3417 16.8536 16.1464L12.7266 12.0196C13.5217 11.0659 14 9.83879 14 8.5ZM4 8.5C4 6.01472 6.01472 4 8.5 4C10.9853 4 13 6.01472 13 8.5C13 10.9853 10.9853 13 8.5 13C6.01472 13 4 10.9853 4 8.5Z",fill:"currentColor"}))),co=te({name:"ResizeSmall",render(){return n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20"},n("g",{fill:"none"},n("path",{d:"M5.5 4A1.5 1.5 0 0 0 4 5.5v1a.5.5 0 0 1-1 0v-1A2.5 2.5 0 0 1 5.5 3h1a.5.5 0 0 1 0 1h-1zM16 5.5A1.5 1.5 0 0 0 14.5 4h-1a.5.5 0 0 1 0-1h1A2.5 2.5 0 0 1 17 5.5v1a.5.5 0 0 1-1 0v-1zm0 9a1.5 1.5 0 0 1-1.5 1.5h-1a.5.5 0 0 0 0 1h1a2.5 2.5 0 0 0 2.5-2.5v-1a.5.5 0 0 0-1 0v1zm-12 0A1.5 1.5 0 0 0 5.5 16h1.25a.5.5 0 0 1 0 1H5.5A2.5 2.5 0 0 1 3 14.5v-1.25a.5.5 0 0 1 1 0v1.25zM8.5 7A1.5 1.5 0 0 0 7 8.5v3A1.5 1.5 0 0 0 8.5 13h3a1.5 1.5 0 0 0 1.5-1.5v-3A1.5 1.5 0 0 0 11.5 7h-3zM8 8.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-3z",fill:"currentColor"})))}}),uo=Ke&&"loading"in document.createElement("img"),fo=(e={})=>{var r;const{root:t=null}=e;return{hash:`${e.rootMargin||"0px 0px 0px 0px"}-${Array.isArray(e.threshold)?e.threshold.join(","):(r=e.threshold)!==null&&r!==void 0?r:"0"}`,options:Object.assign(Object.assign({},e),{root:(typeof t=="string"?document.querySelector(t):t)||document.documentElement})}},Oe=new WeakMap,Pe=new WeakMap,Se=new WeakMap,ho=(e,r,t)=>{if(!e)return()=>{};const o=fo(r),{root:a}=o.options;let d;const c=Oe.get(a);c?d=c:(d=new Map,Oe.set(a,d));let u,s;d.has(o.hash)?(s=d.get(o.hash),s[1].has(e)||(u=s[0],s[1].add(e),u.observe(e))):(u=new IntersectionObserver(f=>{f.forEach(_=>{if(_.isIntersecting){const b=Pe.get(_.target),y=Se.get(_.target);b&&b(),y&&(y.value=!0)}})},o.options),u.observe(e),s=[u,new Set([e])],d.set(o.hash,s));let i=!1;const l=()=>{i||(Pe.delete(e),Se.delete(e),i=!0,s[1].has(e)&&(s[0].unobserve(e),s[1].delete(e)),s[1].size<=0&&d.delete(o.hash),d.size||Oe.delete(a))};return Pe.set(e,l),Se.set(e,t),l},$e=Object.assign(Object.assign({},se.props),{showToolbar:{type:Boolean,default:!0},showToolbarTooltip:Boolean}),tt=ze("n-image");function go(){return{toolbarIconColor:"rgba(255, 255, 255, .9)",toolbarColor:"rgba(0, 0, 0, .35)",toolbarBoxShadow:"none",toolbarBorderRadius:"24px"}}const po=wt({name:"Image",common:bt,peers:{Tooltip:Ct},self:go}),mo=n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M6 5C5.75454 5 5.55039 5.17688 5.50806 5.41012L5.5 5.5V14.5C5.5 14.7761 5.72386 15 6 15C6.24546 15 6.44961 14.8231 6.49194 14.5899L6.5 14.5V5.5C6.5 5.22386 6.27614 5 6 5ZM13.8536 5.14645C13.68 4.97288 13.4106 4.9536 13.2157 5.08859L13.1464 5.14645L8.64645 9.64645C8.47288 9.82001 8.4536 10.0894 8.58859 10.2843L8.64645 10.3536L13.1464 14.8536C13.3417 15.0488 13.6583 15.0488 13.8536 14.8536C14.0271 14.68 14.0464 14.4106 13.9114 14.2157L13.8536 14.1464L9.70711 10L13.8536 5.85355C14.0488 5.65829 14.0488 5.34171 13.8536 5.14645Z",fill:"currentColor"})),vo=n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M13.5 5C13.7455 5 13.9496 5.17688 13.9919 5.41012L14 5.5V14.5C14 14.7761 13.7761 15 13.5 15C13.2545 15 13.0504 14.8231 13.0081 14.5899L13 14.5V5.5C13 5.22386 13.2239 5 13.5 5ZM5.64645 5.14645C5.82001 4.97288 6.08944 4.9536 6.28431 5.08859L6.35355 5.14645L10.8536 9.64645C11.0271 9.82001 11.0464 10.0894 10.9114 10.2843L10.8536 10.3536L6.35355 14.8536C6.15829 15.0488 5.84171 15.0488 5.64645 14.8536C5.47288 14.68 5.4536 14.4106 5.58859 14.2157L5.64645 14.1464L9.79289 10L5.64645 5.85355C5.45118 5.65829 5.45118 5.34171 5.64645 5.14645Z",fill:"currentColor"})),wo=n("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},n("path",{d:"M4.089 4.216l.057-.07a.5.5 0 0 1 .638-.057l.07.057L10 9.293l5.146-5.147a.5.5 0 0 1 .638-.057l.07.057a.5.5 0 0 1 .057.638l-.057.07L10.707 10l5.147 5.146a.5.5 0 0 1 .057.638l-.057.07a.5.5 0 0 1-.638.057l-.07-.057L10 10.707l-5.146 5.147a.5.5 0 0 1-.638.057l-.07-.057a.5.5 0 0 1-.057-.638l.057-.07L9.293 10L4.146 4.854a.5.5 0 0 1-.057-.638l.057-.07l-.057.07z",fill:"currentColor"})),bo=U([U("body >",[w("image-container","position: fixed;")]),w("image-preview-container",`
 position: fixed;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 `),w("image-preview-overlay",`
 z-index: -1;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 background: rgba(0, 0, 0, .3);
 `,[He()]),w("image-preview-toolbar",`
 z-index: 1;
 position: absolute;
 left: 50%;
 transform: translateX(-50%);
 border-radius: var(--n-toolbar-border-radius);
 height: 48px;
 bottom: 40px;
 padding: 0 12px;
 background: var(--n-toolbar-color);
 box-shadow: var(--n-toolbar-box-shadow);
 color: var(--n-toolbar-icon-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[w("base-icon",`
 padding: 0 8px;
 font-size: 28px;
 cursor: pointer;
 `),He()]),w("image-preview-wrapper",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 pointer-events: none;
 `,[xt()]),w("image-preview",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: all;
 margin: auto;
 max-height: calc(100vh - 32px);
 max-width: calc(100vw - 32px);
 transition: transform .3s var(--n-bezier);
 `),w("image",`
 display: inline-flex;
 max-height: 100%;
 max-width: 100%;
 `,[yt("preview-disabled",`
 cursor: pointer;
 `),U("img",`
 border-radius: inherit;
 `)])]),we=32,ot=te({name:"ImagePreview",props:Object.assign(Object.assign({},$e),{onNext:Function,onPrev:Function,clsPrefix:{type:String,required:!0}}),setup(e){const r=se("Image","-image",bo,po,e,$(e,"clsPrefix"));let t=null;const o=V(null),a=V(null),d=V(void 0),c=V(!1),u=V(!1),{localeRef:s}=qt("Image");function i(){const{value:h}=a;if(!t||!h)return;const{style:v}=h,g=t.getBoundingClientRect(),L=g.left+g.width/2,O=g.top+g.height/2;v.transformOrigin=`${L}px ${O}px`}function l(h){var v,g;switch(h.key){case" ":h.preventDefault();break;case"ArrowLeft":(v=e.onPrev)===null||v===void 0||v.call(e);break;case"ArrowRight":(g=e.onNext)===null||g===void 0||g.call(e);break;case"Escape":je();break}}Je(c,h=>{h?_e("keydown",document,l):me("keydown",document,l)}),Qe(()=>{me("keydown",document,l)});let f=0,_=0,b=0,y=0,H=0,B=0,X=0,F=0,R=!1;function I(h){const{clientX:v,clientY:g}=h;b=v-f,y=g-_,Gt(Z)}function m(h){const{mouseUpClientX:v,mouseUpClientY:g,mouseDownClientX:L,mouseDownClientY:O}=h,W=L-v,G=O-g,J=`vertical${G>0?"Top":"Bottom"}`,ne=`horizontal${W>0?"Left":"Right"}`;return{moveVerticalDirection:J,moveHorizontalDirection:ne,deltaHorizontal:W,deltaVertical:G}}function C(h){const{value:v}=o;if(!v)return{offsetX:0,offsetY:0};const g=v.getBoundingClientRect(),{moveVerticalDirection:L,moveHorizontalDirection:O,deltaHorizontal:W,deltaVertical:G}=h||{};let J=0,ne=0;return g.width<=window.innerWidth?J=0:g.left>0?J=(g.width-window.innerWidth)/2:g.right<window.innerWidth?J=-(g.width-window.innerWidth)/2:O==="horizontalRight"?J=Math.min((g.width-window.innerWidth)/2,H-(W!=null?W:0)):J=Math.max(-((g.width-window.innerWidth)/2),H-(W!=null?W:0)),g.height<=window.innerHeight?ne=0:g.top>0?ne=(g.height-window.innerHeight)/2:g.bottom<window.innerHeight?ne=-(g.height-window.innerHeight)/2:L==="verticalBottom"?ne=Math.min((g.height-window.innerHeight)/2,B-(G!=null?G:0)):ne=Math.max(-((g.height-window.innerHeight)/2),B-(G!=null?G:0)),{offsetX:J,offsetY:ne}}function T(h){me("mousemove",document,I),me("mouseup",document,T);const{clientX:v,clientY:g}=h;R=!1;const L=m({mouseUpClientX:v,mouseUpClientY:g,mouseDownClientX:X,mouseDownClientY:F}),O=C(L);b=O.offsetX,y=O.offsetY,Z()}const z=re(tt,null);function p(h){var v,g;if((g=(v=z==null?void 0:z.previewedImgPropsRef.value)===null||v===void 0?void 0:v.onMousedown)===null||g===void 0||g.call(v,h),h.button!==0)return;const{clientX:L,clientY:O}=h;R=!0,f=L-b,_=O-y,H=b,B=y,X=L,F=O,Z(),_e("mousemove",document,I),_e("mouseup",document,T)}function P(h){var v,g;(g=(v=z==null?void 0:z.previewedImgPropsRef.value)===null||v===void 0?void 0:v.onDblclick)===null||g===void 0||g.call(v,h);const L=pe();x=x===L?1:L,Z()}const k=1.5;let A=0,x=1,D=0;function S(){x=1,A=0}function M(){var h;S(),D=0,(h=e.onPrev)===null||h===void 0||h.call(e)}function q(){var h;S(),D=0,(h=e.onNext)===null||h===void 0||h.call(e)}function Y(){D-=90,Z()}function ie(){D+=90,Z()}function xe(){const{value:h}=o;if(!h)return 1;const{innerWidth:v,innerHeight:g}=window,L=Math.max(1,h.naturalHeight/(g-we)),O=Math.max(1,h.naturalWidth/(v-we));return Math.max(3,L*2,O*2)}function pe(){const{value:h}=o;if(!h)return 1;const{innerWidth:v,innerHeight:g}=window,L=h.naturalHeight/(g-we),O=h.naturalWidth/(v-we);return L<1&&O<1?1:Math.max(L,O)}function ye(){const h=xe();x<h&&(A+=1,x=Math.min(h,Math.pow(k,A)),Z())}function Re(){if(x>.5){const h=x;A-=1,x=Math.max(.5,Math.pow(k,A));const v=h-x;Z(!1);const g=C();x+=v,Z(!1),x-=v,b=g.offsetX,y=g.offsetY,Z()}}function Z(h=!0){var v;const{value:g}=o;if(!g)return;const{style:L}=g,O=Lt((v=z==null?void 0:z.previewedImgPropsRef.value)===null||v===void 0?void 0:v.style);let W="";if(typeof O=="string")W=O+";";else for(const J in O)W+=`${Ot(J)}: ${O[J]};`;const G=`transform-origin: center; transform: translateX(${b}px) translateY(${y}px) rotate(${D}deg) scale(${x});`;R?L.cssText=W+"cursor: grabbing; transition: none;"+G:L.cssText=W+"cursor: grab;"+G+(h?"":"transition: none;"),h||g.offsetHeight}function je(){c.value=!c.value,u.value=!0}function ht(){x=pe(),A=Math.ceil(Math.log(x)/Math.log(k)),b=0,y=0,Z()}const gt={setPreviewSrc:h=>{d.value=h},setThumbnailEl:h=>{t=h},toggleShow:je};function pt(h,v){if(e.showToolbarTooltip){const{value:g}=r;return n(Yt,{to:!1,theme:g.peers.Tooltip,themeOverrides:g.peerOverrides.Tooltip,keepAliveOnHover:!1},{default:()=>s.value[v],trigger:()=>h})}else return h}const Fe=E(()=>{const{common:{cubicBezierEaseInOut:h},self:{toolbarIconColor:v,toolbarBorderRadius:g,toolbarBoxShadow:L,toolbarColor:O}}=r.value;return{"--n-bezier":h,"--n-toolbar-icon-color":v,"--n-toolbar-color":O,"--n-toolbar-border-radius":g,"--n-toolbar-box-shadow":L}}),{inlineThemeDisabled:Ue}=ge(),ae=Ue?De("image-preview",void 0,Fe,e):void 0;return Object.assign({previewRef:o,previewWrapperRef:a,previewSrc:d,show:c,appear:Rt(),displayed:u,previewedImgProps:z==null?void 0:z.previewedImgPropsRef,handleWheel(h){h.preventDefault()},handlePreviewMousedown:p,handlePreviewDblclick:P,syncTransformOrigin:i,handleAfterLeave:()=>{S(),D=0,u.value=!1},handleDragStart:h=>{var v,g;(g=(v=z==null?void 0:z.previewedImgPropsRef.value)===null||v===void 0?void 0:v.onDragstart)===null||g===void 0||g.call(v,h),h.preventDefault()},zoomIn:ye,zoomOut:Re,rotateCounterclockwise:Y,rotateClockwise:ie,handleSwitchPrev:M,handleSwitchNext:q,withTooltip:pt,resizeToOrignalImageSize:ht,cssVars:Ue?void 0:Fe,themeClass:ae==null?void 0:ae.themeClass,onRender:ae==null?void 0:ae.onRender},gt)},render(){var e,r;const{clsPrefix:t}=this;return n(fe,null,(r=(e=this.$slots).default)===null||r===void 0?void 0:r.call(e),n(_t,{show:this.show},{default:()=>{var o;return this.show||this.displayed?((o=this.onRender)===null||o===void 0||o.call(this),Ae(n("div",{class:[`${t}-image-preview-container`,this.themeClass],style:this.cssVars,onWheel:this.handleWheel},n(Te,{name:"fade-in-transition",appear:this.appear},{default:()=>this.show?n("div",{class:`${t}-image-preview-overlay`,onClick:this.toggleShow}):null}),this.showToolbar?n(Te,{name:"fade-in-transition",appear:this.appear},{default:()=>{if(!this.show)return null;const{withTooltip:a}=this;return n("div",{class:`${t}-image-preview-toolbar`},this.onPrev?n(fe,null,a(n(N,{clsPrefix:t,onClick:this.handleSwitchPrev},{default:()=>mo}),"tipPrevious"),a(n(N,{clsPrefix:t,onClick:this.handleSwitchNext},{default:()=>vo}),"tipNext")):null,a(n(N,{clsPrefix:t,onClick:this.rotateCounterclockwise},{default:()=>n(ao,null)}),"tipCounterclockwise"),a(n(N,{clsPrefix:t,onClick:this.rotateClockwise},{default:()=>n(io,null)}),"tipClockwise"),a(n(N,{clsPrefix:t,onClick:this.resizeToOrignalImageSize},{default:()=>n(co,null)}),"tipOriginalSize"),a(n(N,{clsPrefix:t,onClick:this.zoomOut},{default:()=>n(so,null)}),"tipZoomOut"),a(n(N,{clsPrefix:t,onClick:this.zoomIn},{default:()=>n(lo,null)}),"tipZoomIn"),a(n(N,{clsPrefix:t,onClick:this.toggleShow},{default:()=>wo}),"tipClose"))}}):null,n(Te,{name:"fade-in-scale-up-transition",onAfterLeave:this.handleAfterLeave,appear:this.appear,onEnter:this.syncTransformOrigin,onBeforeLeave:this.syncTransformOrigin},{default:()=>{const{previewedImgProps:a={}}=this;return Ae(n("div",{class:`${t}-image-preview-wrapper`,ref:"previewWrapperRef"},n("img",Object.assign({},a,{draggable:!1,onMousedown:this.handlePreviewMousedown,onDblclick:this.handlePreviewDblclick,class:[`${t}-image-preview`,a.class],key:this.previewSrc,src:this.previewSrc,ref:"previewRef",onDragstart:this.handleDragStart}))),[[kt,this.show]])}})),[[Tt,{enabled:this.show}]])):null}}))}}),nt=ze("n-image-group"),Co=$e,rt=te({name:"ImageGroup",props:Co,setup(e){let r;const{mergedClsPrefixRef:t}=ge(e),o=`c${Be()}`,a=Pt(),d=s=>{var i;r=s,(i=u.value)===null||i===void 0||i.setPreviewSrc(s)};function c(s){if(!(a!=null&&a.proxy))return;const l=a.proxy.$el.parentElement.querySelectorAll(`[data-group-id=${o}]:not([data-error=true])`);if(!l.length)return;const f=Array.from(l).findIndex(_=>_.dataset.previewSrc===r);~f?d(l[(f+s+l.length)%l.length].dataset.previewSrc):d(l[0].dataset.previewSrc)}Me(nt,{mergedClsPrefixRef:t,setPreviewSrc:d,setThumbnailEl:s=>{var i;(i=u.value)===null||i===void 0||i.setThumbnailEl(s)},toggleShow:()=>{var s;(s=u.value)===null||s===void 0||s.toggleShow()},groupId:o});const u=V(null);return{mergedClsPrefix:t,previewInstRef:u,next:()=>{c(1)},prev:()=>{c(-1)}}},render(){return n(ot,{theme:this.theme,themeOverrides:this.themeOverrides,clsPrefix:this.mergedClsPrefix,ref:"previewInstRef",onPrev:this.prev,onNext:this.next,showToolbar:this.showToolbar,showToolbarTooltip:this.showToolbarTooltip},this.$slots)}}),xo=Object.assign({alt:String,height:[String,Number],imgProps:Object,previewedImgProps:Object,lazy:Boolean,intersectionObserverOptions:Object,objectFit:{type:String,default:"fill"},previewSrc:String,fallbackSrc:String,width:[String,Number],src:String,previewDisabled:Boolean,loadDescription:String,onError:Function,onLoad:Function},$e),it=te({name:"Image",props:xo,inheritAttrs:!1,setup(e){const r=V(null),t=V(!1),o=V(null),a=re(nt,null),{mergedClsPrefixRef:d}=a||ge(e),c={click:()=>{if(e.previewDisabled||t.value)return;const i=e.previewSrc||e.src;if(a){a.setPreviewSrc(i),a.setThumbnailEl(r.value),a.toggleShow();return}const{value:l}=o;l&&(l.setPreviewSrc(i),l.setThumbnailEl(r.value),l.toggleShow())}},u=V(!e.lazy);Ne(()=>{var i;(i=r.value)===null||i===void 0||i.setAttribute("data-group-id",(a==null?void 0:a.groupId)||"")}),Ne(()=>{if(e.lazy&&e.intersectionObserverOptions){let i;const l=Ie(()=>{i==null||i(),i=void 0,i=ho(r.value,e.intersectionObserverOptions,u)});Qe(()=>{l(),i==null||i()})}}),Ie(()=>{var i;e.src,(i=e.imgProps)===null||i===void 0||i.src,t.value=!1});const s=V(!1);return Me(tt,{previewedImgPropsRef:$(e,"previewedImgProps")}),Object.assign({mergedClsPrefix:d,groupId:a==null?void 0:a.groupId,previewInstRef:o,imageRef:r,showError:t,shouldStartLoading:u,loaded:s,mergedOnClick:i=>{var l,f;c.click(),(f=(l=e.imgProps)===null||l===void 0?void 0:l.onClick)===null||f===void 0||f.call(l,i)},mergedOnError:i=>{if(!u.value)return;t.value=!0;const{onError:l,imgProps:{onError:f}={}}=e;l==null||l(i),f==null||f(i)},mergedOnLoad:i=>{const{onLoad:l,imgProps:{onLoad:f}={}}=e;l==null||l(i),f==null||f(i),s.value=!0}},c)},render(){var e,r;const{mergedClsPrefix:t,imgProps:o={},loaded:a,$attrs:d,lazy:c}=this,u=(r=(e=this.$slots).placeholder)===null||r===void 0?void 0:r.call(e),s=this.src||o.src,i=n("img",Object.assign(Object.assign({},o),{ref:"imageRef",width:this.width||o.width,height:this.height||o.height,src:this.showError?this.fallbackSrc:c&&this.intersectionObserverOptions?this.shouldStartLoading?s:void 0:s,alt:this.alt||o.alt,"aria-label":this.alt||o.alt,onClick:this.mergedOnClick,onError:this.mergedOnError,onLoad:this.mergedOnLoad,loading:uo&&c&&!this.intersectionObserverOptions?"lazy":"eager",style:[o.style||"",u&&!a?{height:"0",width:"0",visibility:"hidden"}:"",{objectFit:this.objectFit}],"data-error":this.showError,"data-preview-src":this.previewSrc||this.src}));return n("div",Object.assign({},d,{role:"none",class:[d.class,`${t}-image`,(this.previewDisabled||this.showError)&&`${t}-image--preview-disabled`]}),this.groupId?i:n(ot,{theme:this.theme,themeOverrides:this.themeOverrides,clsPrefix:t,ref:"previewInstRef",showToolbar:this.showToolbar,showToolbarTooltip:this.showToolbarTooltip},{default:()=>i}),!a&&u)}}),yo=w("text",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
`,[j("strong",`
 font-weight: var(--n-font-weight-strong);
 `),j("italic",{fontStyle:"italic"}),j("underline",{textDecoration:"underline"}),j("code",`
 line-height: 1.4;
 display: inline-block;
 font-family: var(--n-font-famliy-mono);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-sizing: border-box;
 padding: .05em .35em 0 .35em;
 border-radius: var(--n-code-border-radius);
 font-size: .9em;
 color: var(--n-code-text-color);
 background-color: var(--n-code-color);
 border: var(--n-code-border);
 `)]),Ro=Object.assign(Object.assign({},se.props),{code:Boolean,type:{type:String,default:"default"},delete:Boolean,strong:Boolean,italic:Boolean,underline:Boolean,depth:[String,Number],tag:String,as:{type:String,validator:()=>!0,default:void 0}}),_o=te({name:"Text",props:Ro,setup(e){const{mergedClsPrefixRef:r,inlineThemeDisabled:t}=ge(e),o=se("Typography","-text",yo,St,e,r),a=E(()=>{const{depth:c,type:u}=e,s=u==="default"?c===void 0?"textColor":`textColor${c}Depth`:Bt("textColor",u),{common:{fontWeightStrong:i,fontFamilyMono:l,cubicBezierEaseInOut:f},self:{codeTextColor:_,codeBorderRadius:b,codeColor:y,codeBorder:H,[s]:B}}=o.value;return{"--n-bezier":f,"--n-text-color":B,"--n-font-weight-strong":i,"--n-font-famliy-mono":l,"--n-code-border-radius":b,"--n-code-text-color":_,"--n-code-color":y,"--n-code-border":H}}),d=t?De("text",E(()=>`${e.type[0]}${e.depth||""}`),a,e):void 0;return{mergedClsPrefix:r,compitableTag:Xt(e,["as","tag"]),cssVars:t?void 0:a,themeClass:d==null?void 0:d.themeClass,onRender:d==null?void 0:d.onRender}},render(){var e,r,t;const{mergedClsPrefix:o}=this;(e=this.onRender)===null||e===void 0||e.call(this);const a=[`${o}-text`,this.themeClass,{[`${o}-text--code`]:this.code,[`${o}-text--delete`]:this.delete,[`${o}-text--strong`]:this.strong,[`${o}-text--italic`]:this.italic,[`${o}-text--underline`]:this.underline}],d=(t=(r=this.$slots).default)===null||t===void 0?void 0:t.call(r);return this.code?n("code",{class:a,style:this.cssVars},this.delete?n("del",null,d):d):this.delete?n("del",{class:a,style:this.cssVars},d):n(this.compitableTag||"span",{class:a,style:this.cssVars},d)}}),de=ze("n-upload"),at="__UPLOAD_DRAGGER__",lt=te({name:"UploadDragger",[at]:!0,setup(e,{slots:r}){const t=re(de,null);return t||Ce("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:o},mergedDisabledRef:{value:a},maxReachedRef:{value:d}}=t;return n("div",{class:[`${o}-upload-dragger`,(a||d)&&`${o}-upload-dragger--disabled`]},r)}}});var st=globalThis&&globalThis.__awaiter||function(e,r,t,o){function a(d){return d instanceof t?d:new t(function(c){c(d)})}return new(t||(t=Promise))(function(d,c){function u(l){try{i(o.next(l))}catch(f){c(f)}}function s(l){try{i(o.throw(l))}catch(f){c(f)}}function i(l){l.done?d(l.value):a(l.value).then(u,s)}i((o=o.apply(e,r||[])).next())})};const dt=e=>e.includes("image/"),qe=(e="")=>{const r=e.split("/"),o=r[r.length-1].split(/#|\?/)[0];return(/\.[^./\\]*$/.exec(o)||[""])[0]},Ye=/(webp|svg|png|gif|jpg|jpeg|jfif|bmp|dpg|ico)$/i,ct=e=>{if(e.type)return dt(e.type);const r=qe(e.name||"");if(Ye.test(r))return!0;const t=e.thumbnailUrl||e.url||"",o=qe(t);return!!(/^data:image\//.test(t)||Ye.test(o))};function To(e){return st(this,void 0,void 0,function*(){return yield new Promise(r=>{if(!e.type||!dt(e.type)){r("");return}r(window.URL.createObjectURL(e))})})}const ko=Ke&&window.FileReader&&window.File;function Lo(e){return e.isDirectory}function Oo(e){return e.isFile}function Po(e,r){return st(this,void 0,void 0,function*(){const t=[];let o,a=0;function d(){a++}function c(){a--,a||o(t)}function u(s){s.forEach(i=>{if(i){if(d(),r&&Lo(i)){const l=i.createReader();d(),l.readEntries(f=>{u(f),c()},()=>{c()})}else Oo(i)&&(d(),i.file(l=>{t.push({file:l,entry:i,source:"dnd"}),c()},()=>{c()}));c()}})}return yield new Promise(s=>{o=s,u(e)}),t})}function he(e){const{id:r,name:t,percentage:o,status:a,url:d,file:c,thumbnailUrl:u,type:s,fullPath:i,batchId:l}=e;return{id:r,name:t,percentage:o!=null?o:null,status:a,url:d!=null?d:null,file:c!=null?c:null,thumbnailUrl:u!=null?u:null,type:s!=null?s:null,fullPath:i!=null?i:null,batchId:l!=null?l:null}}function So(e,r,t){return e=e.toLowerCase(),r=r.toLocaleLowerCase(),t=t.toLocaleLowerCase(),t.split(",").map(a=>a.trim()).filter(Boolean).some(a=>{if(a.startsWith(".")){if(e.endsWith(a))return!0}else if(a.includes("/")){const[d,c]=r.split("/"),[u,s]=a.split("/");if((u==="*"||d&&u&&u===d)&&(s==="*"||c&&s&&s===c))return!0}else return!0;return!1})}const Bo=(e,r)=>{if(!e)return;const t=document.createElement("a");t.href=e,r!==void 0&&(t.download=r),document.body.appendChild(t),t.click(),document.body.removeChild(t)},ut=te({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:r}){const t=re(de,null);t||Ce("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:o,mergedDisabledRef:a,maxReachedRef:d,listTypeRef:c,dragOverRef:u,openOpenFileDialog:s,draggerInsideRef:i,handleFileAddition:l,mergedDirectoryDndRef:f,triggerStyleRef:_}=t,b=E(()=>c.value==="image-card");function y(){a.value||d.value||s()}function H(R){R.preventDefault(),u.value=!0}function B(R){R.preventDefault(),u.value=!0}function X(R){R.preventDefault(),u.value=!1}function F(R){var I;if(R.preventDefault(),!i.value||a.value||d.value){u.value=!1;return}const m=(I=R.dataTransfer)===null||I===void 0?void 0:I.items;m!=null&&m.length?Po(Array.from(m).map(C=>C.webkitGetAsEntry()),f.value).then(C=>{l(C)}).finally(()=>{u.value=!1}):u.value=!1}return()=>{var R;const{value:I}=o;return e.abstract?(R=r.default)===null||R===void 0?void 0:R.call(r,{handleClick:y,handleDrop:F,handleDragOver:H,handleDragEnter:B,handleDragLeave:X}):n("div",{class:[`${I}-upload-trigger`,(a.value||d.value)&&`${I}-upload-trigger--disabled`,b.value&&`${I}-upload-trigger--image-card`],style:_.value,onClick:y,onDrop:F,onDragover:H,onDragenter:B,onDragleave:X},b.value?n(lt,null,{default:()=>It(r.default,()=>[n(N,{clsPrefix:I},{default:()=>n(Wt,null)})])}):r)}}}),Io=te({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:re(de).mergedThemeRef}},render(){return n(et,null,{default:()=>this.show?n(Zt,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),zo=n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},n("g",{fill:"none"},n("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),Do=n("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},n("g",{fill:"none"},n("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var Mo=globalThis&&globalThis.__awaiter||function(e,r,t,o){function a(d){return d instanceof t?d:new t(function(c){c(d)})}return new(t||(t=Promise))(function(d,c){function u(l){try{i(o.next(l))}catch(f){c(f)}}function s(l){try{i(o.throw(l))}catch(f){c(f)}}function i(l){l.done?d(l.value):a(l.value).then(u,s)}i((o=o.apply(e,r||[])).next())})};const be={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},$o=te({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0}},setup(e){const r=re(de),t=V(null),o=V(""),a=E(()=>{const{file:m}=e;return m.status==="finished"?"success":m.status==="error"?"error":"info"}),d=E(()=>{const{file:m}=e;if(m.status==="error")return"error"}),c=E(()=>{const{file:m}=e;return m.status==="uploading"}),u=E(()=>{if(!r.showCancelButtonRef.value)return!1;const{file:m}=e;return["uploading","pending","error"].includes(m.status)}),s=E(()=>{if(!r.showRemoveButtonRef.value)return!1;const{file:m}=e;return["finished"].includes(m.status)}),i=E(()=>{if(!r.showDownloadButtonRef.value)return!1;const{file:m}=e;return["finished"].includes(m.status)}),l=E(()=>{if(!r.showRetryButtonRef.value)return!1;const{file:m}=e;return["error"].includes(m.status)}),f=zt(()=>o.value||e.file.thumbnailUrl||e.file.url),_=E(()=>{if(!r.showPreviewButtonRef.value)return!1;const{file:{status:m},listType:C}=e;return["finished"].includes(m)&&f.value&&C==="image-card"});function b(){r.submit(e.file.id)}function y(m){m.preventDefault();const{file:C}=e;["finished","pending","error"].includes(C.status)?B(C):["uploading"].includes(C.status)?F(C):Mt("upload","The button clicked type is unknown.")}function H(m){m.preventDefault(),X(e.file)}function B(m){const{xhrMap:C,doChange:T,onRemoveRef:{value:z},mergedFileListRef:{value:p}}=r;Promise.resolve(z?z({file:Object.assign({},m),fileList:p}):!0).then(P=>{if(P===!1)return;const k=Object.assign({},m,{status:"removed"});C.delete(m.id),T(k,void 0,{remove:!0})})}function X(m){const{onDownloadRef:{value:C}}=r;Promise.resolve(C?C(Object.assign({},m)):!0).then(T=>{T!==!1&&Bo(m.url,m.name)})}function F(m){const{xhrMap:C}=r,T=C.get(m.id);T==null||T.abort(),B(Object.assign({},m))}function R(){const{onPreviewRef:{value:m}}=r;if(m)m(e.file);else if(e.listType==="image-card"){const{value:C}=t;if(!C)return;C.click()}}const I=()=>Mo(this,void 0,void 0,function*(){const{listType:m}=e;m!=="image"&&m!=="image-card"||r.shouldUseThumbnailUrlRef.value(e.file)&&(o.value=yield r.getFileThumbnailUrlResolver(e.file))});return Ie(()=>{I()}),{mergedTheme:r.mergedThemeRef,progressStatus:a,buttonType:d,showProgress:c,disabled:r.mergedDisabledRef,showCancelButton:u,showRemoveButton:s,showDownloadButton:i,showRetryButton:l,showPreviewButton:_,mergedThumbnailUrl:f,shouldUseThumbnailUrl:r.shouldUseThumbnailUrlRef,renderIcon:r.renderIconRef,imageRef:t,handleRemoveOrCancelClick:y,handleDownloadClick:H,handleRetryClick:b,handlePreviewClick:R}},render(){const{clsPrefix:e,mergedTheme:r,listType:t,file:o,renderIcon:a}=this;let d;const c=t==="image";c||t==="image-card"?d=!this.shouldUseThumbnailUrl(o)||!this.mergedThumbnailUrl?n("span",{class:`${e}-upload-file-info__thumbnail`},a?a(o):ct(o)?n(N,{clsPrefix:e},{default:()=>zo}):n(N,{clsPrefix:e},{default:()=>Do})):n("a",{rel:"noopener noreferer",target:"_blank",href:o.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},t==="image-card"?n(it,{src:this.mergedThumbnailUrl||void 0,previewSrc:o.url||void 0,alt:o.name,ref:"imageRef"}):n("img",{src:this.mergedThumbnailUrl||void 0,alt:o.name})):d=n("span",{class:`${e}-upload-file-info__thumbnail`},a?a(o):n(N,{clsPrefix:e},{default:()=>n(eo,null)}));const s=n(Io,{show:this.showProgress,percentage:o.percentage||0,status:this.progressStatus}),i=t==="text"||t==="image";return n("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,o.url&&o.status!=="error"&&t!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${t}-type`]},n("div",{class:`${e}-upload-file-info`},d,n("div",{class:`${e}-upload-file-info__name`},i&&(o.url&&o.status!=="error"?n("a",{rel:"noopener noreferer",target:"_blank",href:o.url||void 0,onClick:this.handlePreviewClick},o.name):n("span",{onClick:this.handlePreviewClick},o.name)),c&&s),n("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${t}-type`]},this.showPreviewButton?n(ue,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,builtinThemeOverrides:be},{icon:()=>n(N,{clsPrefix:e},{default:()=>n(Kt,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&n(ue,{key:"cancelOrTrash",theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:be,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>n(Dt,null,{default:()=>this.showRemoveButton?n(N,{clsPrefix:e,key:"trash"},{default:()=>n(to,null)}):n(N,{clsPrefix:e,key:"cancel"},{default:()=>n(no,null)})})}),this.showRetryButton&&!this.disabled&&n(ue,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,builtinThemeOverrides:be},{icon:()=>n(N,{clsPrefix:e},{default:()=>n(ro,null)})}),this.showDownloadButton?n(ue,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,builtinThemeOverrides:be},{icon:()=>n(N,{clsPrefix:e},{default:()=>n(oo,null)})}):null)),!c&&s)}}),jo=te({name:"UploadFileList",setup(e,{slots:r}){const t=re(de,null);t||Ce("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:o,mergedClsPrefixRef:a,listTypeRef:d,mergedFileListRef:c,fileListStyleRef:u,cssVarsRef:s,themeClassRef:i,maxReachedRef:l,showTriggerRef:f,imageGroupPropsRef:_}=t,b=E(()=>d.value==="image-card"),y=()=>c.value.map(B=>n($o,{clsPrefix:a.value,key:B.id,file:B,listType:d.value})),H=()=>b.value?n(rt,Object.assign({},_.value),{default:y}):n(et,{group:!0},{default:y});return()=>{const{value:B}=a,{value:X}=o;return n("div",{class:[`${B}-upload-file-list`,b.value&&`${B}-upload-file-list--grid`,X?i==null?void 0:i.value:void 0],style:[X&&s?s.value:"",u.value]},H(),f.value&&!l.value&&b.value&&n(ut,null,r))}}}),Fo=U([w("upload","width: 100%;",[j("dragger-inside",[w("upload-trigger",`
 display: block;
 `)]),j("drag-over",[w("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),w("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[U("&:hover",`
 border: var(--n-dragger-border-hover);
 `),j("disabled",`
 cursor: not-allowed;
 `)]),w("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[U("+",[w("upload-file-list","margin-top: 8px;")]),j("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),j("image-card",`
 width: 96px;
 height: 96px;
 `,[w("base-icon",`
 font-size: 24px;
 `),w("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),w("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[U("a, img","outline: none;"),j("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[w("upload-file","cursor: not-allowed;")]),j("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),w("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[Ve(),w("progress",[Ve({foldPadding:!0})]),U("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[w("upload-file-info",[Q("action",`
 opacity: 1;
 `)])]),j("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[w("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[w("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),Q("name",`
 padding: 0 8px;
 `),Q("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[U("img",`
 width: 100%;
 `)])])]),j("text-type",[w("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),j("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[w("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),w("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[Q("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[U("img",`
 width: 100%;
 `)])]),U("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),U("&:hover",[U("&::before","opacity: 1;"),w("upload-file-info",[Q("thumbnail","opacity: .12;")])])]),j("error-status",[U("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),w("upload-file-info",[Q("name","color: var(--n-item-text-color-error);"),Q("thumbnail","color: var(--n-item-text-color-error);")]),j("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),j("with-url",`
 cursor: pointer;
 `,[w("upload-file-info",[Q("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[U("a",`
 text-decoration: underline;
 `)])])]),w("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[Q("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[w("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),Q("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[w("button",[U("&:not(:last-child)",{marginRight:"4px"}),w("base-icon",[U("svg",[$t()])])]),j("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),j("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),Q("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[U("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),w("upload-file-input",`
 display: block;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var Ge=globalThis&&globalThis.__awaiter||function(e,r,t,o){function a(d){return d instanceof t?d:new t(function(c){c(d)})}return new(t||(t=Promise))(function(d,c){function u(l){try{i(o.next(l))}catch(f){c(f)}}function s(l){try{i(o.throw(l))}catch(f){c(f)}}function i(l){l.done?d(l.value):a(l.value).then(u,s)}i((o=o.apply(e,r||[])).next())})};function Uo(e,r,t){const{doChange:o,xhrMap:a}=e;let d=0;function c(s){var i;let l=Object.assign({},r,{status:"error",percentage:d});a.delete(r.id),l=he(((i=e.onError)===null||i===void 0?void 0:i.call(e,{file:l,event:s}))||l),o(l,s)}function u(s){var i;if(e.isErrorState){if(e.isErrorState(t)){c(s);return}}else if(t.status<200||t.status>=300){c(s);return}let l=Object.assign({},r,{status:"finished",percentage:d});a.delete(r.id),l=he(((i=e.onFinish)===null||i===void 0?void 0:i.call(e,{file:l,event:s}))||l),o(l,s)}return{handleXHRLoad:u,handleXHRError:c,handleXHRAbort(s){const i=Object.assign({},r,{status:"removed",file:null,percentage:d});a.delete(r.id),o(i,s)},handleXHRProgress(s){const i=Object.assign({},r,{status:"uploading"});if(s.lengthComputable){const l=Math.ceil(s.loaded/s.total*100);i.percentage=l,d=l}o(i,s)}}}function Eo(e){const{inst:r,file:t,data:o,headers:a,withCredentials:d,action:c,customRequest:u}=e,{doChange:s}=e.inst;let i=0;u({file:t,data:o,headers:a,withCredentials:d,action:c,onProgress(l){const f=Object.assign({},t,{status:"uploading"}),_=l.percent;f.percentage=_,i=_,s(f)},onFinish(){var l;let f=Object.assign({},t,{status:"finished",percentage:i});f=he(((l=r.onFinish)===null||l===void 0?void 0:l.call(r,{file:f}))||f),s(f)},onError(){var l;let f=Object.assign({},t,{status:"error",percentage:i});f=he(((l=r.onError)===null||l===void 0?void 0:l.call(r,{file:f}))||f),s(f)}})}function Ho(e,r,t){const o=Uo(e,r,t);t.onabort=o.handleXHRAbort,t.onerror=o.handleXHRError,t.onload=o.handleXHRLoad,t.upload&&(t.upload.onprogress=o.handleXHRProgress)}function ft(e,r){return typeof e=="function"?e({file:r}):e||{}}function Ao(e,r,t){const o=ft(r,t);o&&Object.keys(o).forEach(a=>{e.setRequestHeader(a,o[a])})}function No(e,r,t){const o=ft(r,t);o&&Object.keys(o).forEach(a=>{e.append(a,o[a])})}function Vo(e,r,t,{method:o,action:a,withCredentials:d,responseType:c,headers:u,data:s}){const i=new XMLHttpRequest;i.responseType=c,e.xhrMap.set(t.id,i),i.withCredentials=d;const l=new FormData;if(No(l,s,t),l.append(r,t.file),Ho(e,t,i),a!==void 0){i.open(o.toUpperCase(),a),Ao(i,u,t),i.send(l);const f=Object.assign({},t,{status:"uploading"});e.doChange(f)}}const Xo=Object.assign(Object.assign({},se.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>ko?ct(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerStyle:[String,Object],renderIcon:Object}),Wo=te({name:"Upload",props:Xo,setup(e){e.abstract&&e.listType==="image-card"&&Ce("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:r,inlineThemeDisabled:t}=ge(e),o=se("Upload","-upload",Fo,jt,e,r),a=Ft(e),d=E(()=>{const{max:p}=e;return p!==void 0?b.value.length>=p:!1}),c=V(e.defaultFileList),u=$(e,"fileList"),s=V(null),i={value:!1},l=V(!1),f=new Map,_=Jt(u,c),b=E(()=>_.value.map(he));function y(){var p;(p=s.value)===null||p===void 0||p.click()}function H(p){const P=p.target;F(P.files?Array.from(P.files).map(k=>({file:k,entry:null,source:"input"})):null,p),P.value=""}function B(p){const{"onUpdate:fileList":P,onUpdateFileList:k}=e;P&&Xe(P,p),k&&Xe(k,p),c.value=p}const X=E(()=>e.multiple||e.directory);function F(p,P){if(!p||p.length===0)return;const{onBeforeUpload:k}=e;p=X.value?p:[p[0]];const{max:A,accept:x}=e;p=p.filter(({file:S,source:M})=>M==="dnd"&&(x!=null&&x.trim())?So(S.name,S.type,x):!0),A&&(p=p.slice(0,A-b.value.length));const D=Be();Promise.all(p.map(({file:S,entry:M})=>Ge(this,void 0,void 0,function*(){var q;const Y={id:Be(),batchId:D,name:S.name,status:"pending",percentage:0,file:S,url:null,type:S.type,thumbnailUrl:null,fullPath:(q=M==null?void 0:M.fullPath)!==null&&q!==void 0?q:`/${S.webkitRelativePath||S.name}`};return!k||(yield k({file:Y,fileList:b.value}))!==!1?Y:null}))).then(S=>Ge(this,void 0,void 0,function*(){let M=Promise.resolve();S.forEach(q=>{M=M.then(Et).then(()=>{q&&I(q,P,{append:!0})})}),yield M})).then(()=>{e.defaultUpload&&R()})}function R(p){const{method:P,action:k,withCredentials:A,headers:x,data:D,name:S}=e,M=p!==void 0?b.value.filter(Y=>Y.id===p):b.value,q=p!==void 0;M.forEach(Y=>{const{status:ie}=Y;(ie==="pending"||ie==="error"&&q)&&(e.customRequest?Eo({inst:{doChange:I,xhrMap:f,onFinish:e.onFinish,onError:e.onError},file:Y,action:k,withCredentials:A,headers:x,data:D,customRequest:e.customRequest}):Vo({doChange:I,xhrMap:f,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},S,Y,{method:P,action:k,withCredentials:A,responseType:e.responseType,headers:x,data:D}))})}const I=(p,P,k={append:!1,remove:!1})=>{const{append:A,remove:x}=k,D=Array.from(b.value),S=D.findIndex(M=>M.id===p.id);if(A||x||~S){A?D.push(p):x?D.splice(S,1):D.splice(S,1,p);const{onChange:M}=e;M&&M({file:p,fileList:D,event:P}),B(D)}};function m(p){var P;if(p.thumbnailUrl)return p.thumbnailUrl;const{createThumbnailUrl:k}=e;return k?(P=k(p.file,p))!==null&&P!==void 0?P:p.url||"":p.url?p.url:p.file?To(p.file):""}const C=E(()=>{const{common:{cubicBezierEaseInOut:p},self:{draggerColor:P,draggerBorder:k,draggerBorderHover:A,itemColorHover:x,itemColorHoverError:D,itemTextColorError:S,itemTextColorSuccess:M,itemTextColor:q,itemIconColor:Y,itemDisabledOpacity:ie,lineHeight:xe,borderRadius:pe,fontSize:ye,itemBorderImageCardError:Re,itemBorderImageCard:Z}}=o.value;return{"--n-bezier":p,"--n-border-radius":pe,"--n-dragger-border":k,"--n-dragger-border-hover":A,"--n-dragger-color":P,"--n-font-size":ye,"--n-item-color-hover":x,"--n-item-color-hover-error":D,"--n-item-disabled-opacity":ie,"--n-item-icon-color":Y,"--n-item-text-color":q,"--n-item-text-color-error":S,"--n-item-text-color-success":M,"--n-line-height":xe,"--n-item-border-image-card-error":Re,"--n-item-border-image-card":Z}}),T=t?De("upload",void 0,C,e):void 0;Me(de,{mergedClsPrefixRef:r,mergedThemeRef:o,showCancelButtonRef:$(e,"showCancelButton"),showDownloadButtonRef:$(e,"showDownloadButton"),showRemoveButtonRef:$(e,"showRemoveButton"),showRetryButtonRef:$(e,"showRetryButton"),onRemoveRef:$(e,"onRemove"),onDownloadRef:$(e,"onDownload"),mergedFileListRef:b,triggerStyleRef:$(e,"triggerStyle"),shouldUseThumbnailUrlRef:$(e,"shouldUseThumbnailUrl"),renderIconRef:$(e,"renderIcon"),xhrMap:f,submit:R,doChange:I,showPreviewButtonRef:$(e,"showPreviewButton"),onPreviewRef:$(e,"onPreview"),getFileThumbnailUrlResolver:m,listTypeRef:$(e,"listType"),dragOverRef:l,openOpenFileDialog:y,draggerInsideRef:i,handleFileAddition:F,mergedDisabledRef:a.mergedDisabledRef,maxReachedRef:d,fileListStyleRef:$(e,"fileListStyle"),abstractRef:$(e,"abstract"),acceptRef:$(e,"accept"),cssVarsRef:t?void 0:C,themeClassRef:T==null?void 0:T.themeClass,onRender:T==null?void 0:T.onRender,showTriggerRef:$(e,"showTrigger"),imageGroupPropsRef:$(e,"imageGroupProps"),mergedDirectoryDndRef:E(()=>{var p;return(p=e.directoryDnd)!==null&&p!==void 0?p:e.directory})});const z={clear:()=>{c.value=[]},submit:R,openOpenFileDialog:y};return Object.assign({mergedClsPrefix:r,draggerInsideRef:i,inputElRef:s,mergedTheme:o,dragOver:l,mergedMultiple:X,cssVars:t?void 0:C,themeClass:T==null?void 0:T.themeClass,onRender:T==null?void 0:T.onRender,handleFileInputChange:H},z)},render(){var e,r;const{draggerInsideRef:t,mergedClsPrefix:o,$slots:a,directory:d,onRender:c}=this;if(a.default&&!this.abstract){const s=a.default()[0];!((e=s==null?void 0:s.type)===null||e===void 0)&&e[at]&&(t.value=!0)}const u=n("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${o}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:d||void 0,directory:d||void 0}));return this.abstract?n(fe,null,(r=a.default)===null||r===void 0?void 0:r.call(a),n(Ut,{to:"body"},u)):(c==null||c(),n("div",{class:[`${o}-upload`,t.value&&`${o}-upload--dragger-inside`,this.dragOver&&`${o}-upload--drag-over`,this.themeClass],style:this.cssVars},u,this.showTrigger&&this.listType!=="image-card"&&n(ut,null,a),this.showFileList&&n(jo,null,a)))}}),Zo={class:"h-150 f-c-c flex-col"},qo={class:"h-160 f-c-c"},hn=Object.assign({name:"Upload"},{__name:"index",setup(e){const{copy:r,copied:t}=Ht(),o=At([{url:"https://cdn.qszone.com/images/5c23d52f880511ebb6edd017c2d2eca2.jpg"},{url:"https://cdn.qszone.com/images/5c23d52f880511ebb6edd017c2d2eca2.jpg"},{url:"https://cdn.qszone.com/images/5c23d52f880511ebb6edd017c2d2eca2.jpg"},{url:"https://cdn.qszone.com/images/5c23d52f880511ebb6edd017c2d2eca2.jpg"}]);Je(t,c=>{c&&$message.success("已复制到剪切板")});function a({file:c}){var u;return(u=c.file)!=null&&u.type.startsWith("image/")?!0:($message.error("只能上传图片"),!1)}function d(s){return Ee(this,arguments,function*({file:c,onFinish:u}){(!c||!c.type)&&$message.error("请选择文件"),$message.loading("上传中..."),setTimeout(()=>{$message.success("上传成功"),o.push({fileName:c.name,url:URL.createObjectURL(c.file)}),u()},1500)})}return(c,u)=>{const s=vt,i=_o,l=lt,f=Wo,_=it,b=ue,y=Qt,H=Vt,B=rt,X=mt;return ce(),ke(X,null,{default:K(()=>[ee(f,{class:"mx-auto w-[75%] p-20 text-center","custom-request":d,"show-file-list":!1,accept:".png,.jpg,.jpeg",onBeforeUpload:a},{default:K(()=>[ee(l,null,{default:K(()=>[Le("div",Zo,[ee(s,{icon:"mdi:upload",size:68,class:"mb-12 c-primary"}),ee(i,{class:"text-14 c-gray"},{default:K(()=>[ve("点击或者拖动文件到该区域来上传")]),_:1})])]),_:1})]),_:1}),le(o)&&le(o).length?(ce(),ke(H,{key:0,class:"mt-16 items-center"},{default:K(()=>[ee(B,null,{default:K(()=>[ee(y,{justify:"space-between",align:"center"},{default:K(()=>[(ce(!0),We(fe,null,Ze(le(o),(F,R)=>(ce(),ke(H,{key:R,class:"w-280 hover:card-shadow"},{default:K(()=>[Le("div",qo,[ee(_,{width:"200",src:F.url},null,8,["src"])]),ee(y,{class:"mt-16",justify:"space-evenly"},{default:K(()=>[ee(b,{dashed:"",type:"primary",onClick:I=>le(r)(F.url)},{default:K(()=>[ve("url")]),_:2},1032,["onClick"]),ee(b,{dashed:"",type:"primary",onClick:I=>le(r)(`![${F.fileName}](${F.url})`)},{default:K(()=>[ve(" MD ")]),_:2},1032,["onClick"]),ee(b,{dashed:"",type:"primary",onClick:I=>le(r)(`<img src="${F.url}" />`)},{default:K(()=>[ve(" img ")]),_:2},1032,["onClick"])]),_:2},1024)]),_:2},1024))),128)),(ce(),We(fe,null,Ze(4,F=>Le("div",{key:F,class:"w-280"})),64))]),_:1})]),_:1})]),_:1})):Nt("",!0)]),_:1})}}});export{hn as default};
